#include "3d_point_cloud.h"
#include "Assignment_Learning.h"

int main()
{
	PointCloud3D();
	//Assignment_Learnning();
	system("pause");
	return 0;
}