#ifndef _3D_POINT_CLOUD__
#define _3D_POINT_CLOUD__

#include <dlib\gui_widgets.h>
#include <dlib\image_transforms.h>
#include <cmath>
#include <vector>

void PointCloud3D();

#endif