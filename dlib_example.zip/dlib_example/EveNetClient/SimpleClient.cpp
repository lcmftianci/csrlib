#define WIN32

#ifdef WIN32
#include <Ws2tcpip.h>
#include <winsock2.h>
#include <corecrt_wstdio.h>
#else
#include<sys/socket.h>  
#include<netinet/in.h>  
#include <sys/types.h> 
#include<arpa/inet.h>  
#include<unistd.h> 
#include<errno.h> 
#endif
#include <iostream> 
#include <stdio.h>  
#include <string.h>  
#include <stdlib.h> 
#include <event.h>  
#include <event2/util.h>


#pragma comment(lib, "libevent_core.lib")
#pragma comment(lib, "libevent_extras.lib")
#pragma comment(lib, "libevent.lib")
#pragma comment(lib, "Ws2_32.lib")
#pragma comment(lib, "wsock32.lib")


/*
* ��libjpeg-turboΪvs2010����ʱ��vs2015�¾�̬����libjpeg-turbo�����ӳ���:�Ҳ���__iob_func,
* ����__iob_func��__acrt_iob_func��ת���������������,
* ��libjpeg-turbo��vs2015����ʱ������Ҫ�˲����ļ�
*/
#if _MSC_VER>=1900
#include "stdio.h" 
_ACRTIMP_ALT FILE* __cdecl __acrt_iob_func(unsigned);
#ifdef __cplusplus 
extern "C"
#endif 
FILE* __cdecl __iob_func(unsigned i) {
	return __acrt_iob_func(i);
}
#endif /* _MSC_VER>=1900 */

//extern "C" 
//{
//	FILE _iob[3] = 
//	{ 
//		__iob_func()[0], 
//		__iob_func()[1], 
//		__iob_func()[2] 
//	}; 
//}


//#ifdef __cplusplus
//extern "C"
//#endif
//FILE _iob[3] = { __iob_func()[0], __iob_func()[1], __iob_func()[2] };


using namespace std;

int tcp_connect_server(const char* server_ip, int port)
{
#ifdef WIN32
	SOCKET sockfd; int status, save_errno;
#else
	int sockfd, status, save_errno;
#endif

	struct sockaddr_in server_addr;
	memset(&server_addr, 0, sizeof(server_addr));
	server_addr.sin_family = AF_INET;
	server_addr.sin_port = htons(port);
#ifdef WIN32
	server_addr.sin_addr.S_un.S_addr = inet_addr(server_ip);
	//inet_pton(PF_INET, server_ip, (void *)&server_addr);
#else
	//status = inet_aton(server_ip, &server_addr.sin_addr);
	//status = InetPton(server_ip, &server_addr.sin_addr);
#endif
	sockfd = socket(PF_INET, SOCK_STREAM, 0);
	if (sockfd == -1)
		return sockfd;
	status = connect(sockfd, (struct sockaddr*)&server_addr, sizeof(server_addr));
	if (status == -1)
	{
		save_errno = errno;
		closesocket(sockfd);
		errno = save_errno;
		return -1;
	}
	evutil_make_socket_nonblocking(sockfd);
	return 0;
}

void cmd_msg_cb(evutil_socket_t fd, short events, void* arg)
{
	char msg[1024];
#ifdef WIN32
	int ret = 0, len;
	len = recv(fd, msg, sizeof(msg), ret);
#else
	int ret = read(fd, msg, sizeof(msg));
#endif
	if (ret <= 0)
	{
		perror("read fail ");
		exit(1);
	}

	int sockfd = *((int*)arg);

	//���ն˵���Ϣ���͸���������  
	//Ϊ�˼������������дһ�����ݵ���� 
#ifdef WIN32
	send(sockfd, msg, sizeof(msg), ret);
#else
	write(sockfd, msg, ret);
#endif
}

void socket_read_cb(evutil_socket_t fd, short events, void *arg)
{
	char msg[1024];

#ifdef WIN32
	int ret = 0, len;
	len = recv(fd, msg, sizeof(msg), ret);
#else
	//Ϊ�˼�����������Ƕ�һ�����ݵ����  
	int len = read(fd, msg, sizeof(msg) - 1);
#endif
	if (len <= 0)
	{
		perror("read fail ");
		exit(1);
	}

	msg[len] = '\0';
	printf("recv %s from server\n", msg);
}

int main(void)
{
#ifdef WIN32
	//��ʼ��WinSock
	WSADATA WSAData;
	if (WSAStartup(MAKEWORD(2, 0), &WSAData) != 0)
	{
		return -1;
	}
#endif
	cout << "libevent" << endl;
	//�������������Ƿ������˵�IP��ַ���˿ں�  
	int sockfd = tcp_connect_server("192.168.100.54", atoi("10000"));
	if (sockfd == -1)
	{
		perror("tcp_connect error ");
		return -1;
	}

	printf("connect to server successful\n");

	struct event_base* base = event_base_new();

	struct event *ev_sockfd = event_new(base, sockfd, EV_READ | EV_PERSIST,	socket_read_cb, NULL);
	event_add(ev_sockfd, NULL);

	//�����ն������¼�  
	//struct event* ev_cmd = event_new(base, STDIN_FILENO, EV_READ | EV_PERSIST, cmd_msg_cb, (void*)&sockfd);
	struct event* ev_cmd = event_new(base, 0, EV_READ | EV_PERSIST, cmd_msg_cb, (void*)&sockfd);

	event_add(ev_cmd, NULL);

	event_base_dispatch(base);
	WSACleanup();
	printf("finished \n");
	getchar();
	return 0;
}